<?php

 phpinfo()

?>
<div class="modal zoomPopup">
    <a href="javascript:;" class="close"></a>
  <div class="modalBody">
    <img src="" alt=""> </div>
</div>
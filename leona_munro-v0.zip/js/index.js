var INDEX = {

  init: function() {},

  events: function() {},

  resize: function() {},

  load: function() {},

  pageInit: function() {},

  carouselMove: function() {},

};
